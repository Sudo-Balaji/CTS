package com.cognizant.healthCareAppointment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HealthCareAppointmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
