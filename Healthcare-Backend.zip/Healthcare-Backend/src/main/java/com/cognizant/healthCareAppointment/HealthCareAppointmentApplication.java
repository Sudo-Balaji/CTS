package com.cognizant.healthCareAppointment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HealthCareAppointmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(HealthCareAppointmentApplication.class, args);
	}

}
