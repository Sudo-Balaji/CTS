package com.cognizant.healthCareAppointment.entity;

public enum AppointmentStatus {
    BOOKED,
    CANCELLED,
    COMPLETED
}